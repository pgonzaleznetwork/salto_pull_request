---
layout: default
---
# MDTSecondAccountTriggerHandler class

This is a simple trigger handler class for Account that is used to demonstrate the custom metadata trigger handler approach to multiple trigger handler classes ordered by and controlled by custom metadata.

## Related

[MetadataTriggerHandler](https://github.com/trailheadapps/apex-recipes/wiki/MetadataTriggerHandler.md)

---
## Methods
### `beforeUpdate()` → `void`
---
