---
layout: default
---
# QuiddityRecipes class

Demonstrates the use and functionaly of Quiddity

---
## Methods
### `demonstrateGetQuiddity()` → `Quiddity`

demonstrates the code needed to get the current requests Quiddity value.

#### Return

**Type**

Quiddity

**Description**

System.Quiddity

---
