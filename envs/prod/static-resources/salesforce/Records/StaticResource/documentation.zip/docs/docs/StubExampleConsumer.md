---
layout: default
---
# StubExampleConsumer class
---
## Constructors
### `StubExampleConsumer(StubExample stub)`
---
## Methods
### `getGreeting()` → `String`
### `getIsTrue()` → `Boolean`
### `setGreeting(String greeting)` → `void`
### `setGreeting(Integer someInt)` → `void`
### `setGreeting(Boolean someBoolean)` → `void`
---
